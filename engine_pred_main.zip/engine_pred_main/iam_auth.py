import requests
import json
import time

# IBM Cloud IAM Token API URL
IAM_URL = "https://iam.cloud.ibm.com/identity/token"

# Your IBM Cloud API Key (Replace with your actual API Key)
API_KEY = "0_225xqiFf2vFvANXisoCOHyJwT0JKZF5_ccrFDPz8mP"

# Store token and expiration time
iam_token = None
expires_at = 0  # Timestamp when token expires

def get_iam_token():
    global iam_token, expires_at

    # Check if token is still valid
    if iam_token and time.time() < expires_at:
        print("✅ Using cached IAM token")
        return iam_token

    # Request a new token
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {"apikey": API_KEY, "grant_type": "urn:ibm:params:oauth:grant-type:apikey"}

    response = requests.post(IAM_URL, headers=headers, data=data)

    if response.status_code == 200:
        token_data = response.json()
        iam_token = token_data["access_token"]
        expires_in = token_data.get("expires_in", 3600)  # Default to 1 hour
        expires_at = time.time() + expires_in - 60  # Renew 1 min before expiry

        # Save token to a file
        with open("iam_token.json", "w") as f:
            json.dump({"token": iam_token, "expires_at": expires_at}, f)

        print("✅ New IAM token fetched and saved.")
        return iam_token
    else:
        print("❌ Failed to get IAM token:", response.text)
        return None

# Manual test if running script directly
if __name__ == "__main__":
    print("🔍 Fetching IAM token...")
    token = get_iam_token()
    if token:
        print(f"✅ Token: {token[:50]}... (truncated)")
    else:
        print("❌ Token fetch failed!")
